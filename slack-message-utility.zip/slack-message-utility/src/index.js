const { sendMessage } = require("./slack/sendMessage");

const message = process.argv[2] || "Hello, Slack!";
const useHtml = process.argv[3] === "html";

sendMessage(message, useHtml)
  .then(() => console.log("Message sent to Slack successfully."))
  .catch((error) =>
    console.error("Error sending message to Slack:", error.message)
  );
