const axios = require("axios");
const { readFileSync } = require("fs");
const { join } = require("path");
require("dotenv").config();

const WEBHOOK_URL = process.env.SLACK_WEBHOOK_URL;

if (!WEBHOOK_URL) {
  throw new Error("SLACK_WEBHOOK_URL environment variable is not set.");
}

const templatesPath = join(__dirname, "templates");

function loadTemplate(templateName) {
  const templatePath = join(templatesPath, templateName);
  const template = readFileSync(templatePath, "utf-8");
  return JSON.parse(template);
}

async function sendMessage(message, useHtml = false) {
  const templateName = useHtml
    ? "htmlMessageTemplate.json"
    : "messageTemplate.json";
  const template = loadTemplate(templateName);

  const payload = useHtml
    ? {
        blocks: template.blocks.map((block) => ({
          ...block,
          text: {
            ...block.text,
            text: block.text.text.replace("{{message}}", message),
          },
        })),
      }
    : { text: template.text.replace("{{message}}", message) };

  await axios.post(WEBHOOK_URL, payload);
}

module.exports = { sendMessage };
